<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require "database.php";
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$messege=$_POST['messege'];
$sql = "INSERT INTO `contact` (`id`, `fname`, `lname`, `email`, `phone`, `Messege`, `date`) VALUES ('', '$fname', '$lname', '$email', '$phone', '$messege', current_timestamp())";
if ($conn->query($sql) == TRUE) {
    echo "New record created successfully";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
  
  $conn->close();

?>