<?php
 $servername = "localhost";
$username = "id13988086_ayushwoman";
$password = "@vkvam1#VKVAM1" ;
$dbase = "id13988086_woman";
$conn = new mysqli($servername, $username, $password,$dbase);
if ($conn->connect_error) {
    echo "there is technical problems " ;
    exit;
}
?>